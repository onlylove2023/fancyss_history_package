{
  "gfwlist": {
    "name": "gfwlist.conf",
    "date": "2023-05-30 11:06",
    "md5": "892c22c850a1ee806ae8821fc682d0af",
    "count": "5566"
  },
  "chnroute": {
    "name": "chnroute.txt",
    "date": "2023-05-30 11:06",
    "md5": "4d1e358ae52b078da151b30a2fbe58a1",
    "count": "3633",
    "count_ip": "299797150",
    "source": "misakaio",
    "url": "https://github.com/misakaio/chnroutes2/blob/master/chnroutes.txt"
  },
  "chnroute2": {
    "name": "chnroute2.txt",
    "date": "2023-05-30 11:06",
    "md5": "129cb57658181d8948ace37f35bbca68",
    "count": "6368",
    "count_ip": "17534691524",
    "source": "ipip",
    "url": "https://github.com/firehol/blocklist-ipsets/blob/master/ipip_country/ipip_country_cn.netset"
  },
  "chnroute3": {
    "name": "chnroute3.txt",
    "date": "2023-05-30 11:06",
    "md5": "4b5454707dd7d9d1755ea081d551184d",
    "count": "8646",
    "count_ip": "343103092",
    "source": "apnic",
    "url": "http://ftp.apnic.net/apnic/stats/apnic/delegated-apnic-latest"
  },
  "cdn_china": {
    "name": "cdn.txt",
    "date": "2023-05-30 11:06",
    "md5": "a20cb5bc2286c147ad21641a56573d06",
    "count": "64713"
  },
  "apple_china": {
    "name": "apple_china.txt",
    "date": "2023-05-30 11:06",
    "md5": "44bae4961701c156b34f06bb43df54e1",
    "count": "140"
  },
  "google_china": {
    "name": "google_china.txt",
    "date": "2023-05-30 11:06",
    "md5": "a4d215b3c100de14d83ee2416c19cb7b",
    "count": "159"
  },
  "cdn_test": {
    "name": "cdn_test.txt",
    "date": "2022-10-31 23:23",
    "md5": "576a8d266539be4d7885e665f9a3f7cf",
    "count": "81"
  }
}
